﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringOpsApp
{
    class Program
    {      
        static void Main(string[] args)
        {
            while(true)
            {
                PerformOperation();
            }
        }

        private static void PerformOperation()
        {
            Console.WriteLine("Enter text to be analysed");
            var input = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter which operations to do on the supplied text, ‘1’ for a duplicate character check, ‘2’ to count the number of vowels, ‘3’ to check if there are more vowels or non vowels, or any combination of ‘1’, ‘2’ and ‘3’ to perform multiple checks");
            var ops = Convert.ToString(Console.ReadLine().ToLower()).Replace(" ", "");

            MyOperations myops = new MyOperations(input);

            foreach (char item in ops.ToCharArray())
            {
                switch (item)
                {
                    case '1':
                        var result = myops.checkDuplicates();

                        if (!string.IsNullOrEmpty(result))
                        {
                            Console.WriteLine("Found the following duplicates:" + result);
                        }
                        else
                        {
                            Console.WriteLine("No duplicate values were found");
                        }
                        break;
                    case '2':
                        int uniqVowels = myops.getVowels();
                        if (uniqVowels > 0)
                        {
                            Console.WriteLine("The number of vowels is " + uniqVowels);
                        }
                        else
                        {
                            Console.WriteLine("No vowels were found.");
                        }
                        break;
                    case '3':
                        int vowels = myops.getVowels();
                        int nonVowels = myops.getNonVowels();
                        if (vowels > nonVowels)
                        {
                            Console.WriteLine("The text has more vowels than non vowels");
                        }
                        else if (vowels < nonVowels)
                        {
                            Console.WriteLine("The text has more non vowels than vowels");
                        }
                        else if (vowels == nonVowels)
                        {
                            Console.WriteLine("The text has an equal amount of vowels and non vowels");
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
