﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringOpsApp
{
    public interface IStringOps
    {
        string checkDuplicates();
        int getVowels();
        int getNonVowels();
    }

    public class MyOperations : IStringOps
    {
        public string Input { set; get; }

        public MyOperations(string Inputstr)
        {
            Input = Inputstr.ToLower().Replace(" ","");
        }

        private static char[] vowels = { 'a', 'e', 'i', 'o', 'u' };

        public string checkDuplicates()
        {
            string output = string.Empty;
            try
            {
                Dictionary<char, int> dup_dic = new Dictionary<char, int>();

                for (int i = 0; i < Input.Length; i++)
                {
                    if (dup_dic.ContainsKey(Input[i]))
                    {
                        int count = dup_dic[Input[i]];
                        dup_dic.Remove(Input[i]);
                        dup_dic.Add(Input[i], count + 1);
                    }
                    else
                    {
                        dup_dic.Add(Input[i], 1);
                    }
                }

                //sub select on dic key items with a count > 1
                var keyDic = dup_dic.Where(v => v.Value > 1).Select(x => x.Key);

                if (keyDic != null && keyDic.Count() > 0)
                {
                    StringBuilder sb = new StringBuilder();
                    foreach (var kv in keyDic)
                    {
                        sb.Append(kv);
                    }

                    output = sb.ToString();
                }

            }
            catch (Exception ex)
            {

                throw;
            }
            return output;
        }

        public int getNonVowels()
        {
            int nonVowelsCount = 0;
            try
            {
                Dictionary<char, int> uniqueNon_dic = new Dictionary<char, int>();

                for (int i = 0; i < Input.Length; i++)
                {
                    // Check the nonvowel in the array
                    if (!vowels.Contains(Input[i]))
                    {
                        if(!uniqueNon_dic.ContainsKey(Input[i]))
                        {
                            uniqueNon_dic.Add(Input[i], 1);
                            nonVowelsCount++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return nonVowelsCount;
        }

        public int getVowels()
        {
            int vowelsCount = 0;
            try
            {
                Dictionary<char, int> uniqueV_dic = new Dictionary<char, int>();

                for (int i = 0; i < Input.Length; i++)
                {
                    // Check the vowel in the array
                    if (vowels.Contains(Input[i]))
                    {
                        if (!uniqueV_dic.ContainsKey(Input[i]))
                        {
                            uniqueV_dic.Add(Input[i], 1);
                            vowelsCount++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return vowelsCount;
        }
    }
}
