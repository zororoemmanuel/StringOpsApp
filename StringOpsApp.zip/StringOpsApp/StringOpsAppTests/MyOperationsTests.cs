﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using StringOpsApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringOpsApp.Tests
{
    [TestClass()]
    public class MyOperationsTests
    {
        [TestMethod()]
        public void checkDuplicatesTest()
        {
            var ops = new MyOperations("I like eating apples");
            string result = ops.checkDuplicates();
            Assert.AreEqual(result, "ileap");
        }

        [TestMethod()]
        public void getNonVowelsTest()
        {
            var ops = new MyOperations("jkl kkjh");
            var result = ops.getNonVowels();
            Assert.AreEqual(result, 4);
        }

        [TestMethod()]
        public void getVowelsTest()
        {
            var ops = new MyOperations("I like eating apples");
            var result = ops.getVowels();
            Assert.AreEqual(result, 3);
        }
    }
}